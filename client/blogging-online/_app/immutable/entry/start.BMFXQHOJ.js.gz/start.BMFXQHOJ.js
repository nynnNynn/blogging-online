import{a as t}from"../chunks/oWD2vhOK.js";export{t as start};
